/**
 ** Group No.: 37 - Customer Feedback Management System
 * 
 * Group member details;
 * Karawugodage Don Esanda Sebastian Harshan - 1935123
 * Nandakumar Ashvinthan - 1935129
 * Muhammad Aslam - 1939084
 */

package ServerSide;


import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
//import java.sql.ResultSet;
//import java.util.Vector;
//import java.util.Vector;
//import java.util.HashMap;

public interface FeedbackInterface extends Remote {

	//for user registration 
	/**
	 * @author Karawugodage Don Esanda Sebastian Harshan - 1935123
	 * @param name
	 * @param username
	 * @param email
	 * @param password
	 * @param securityQuestion
	 * @param securityAnswer
	 * @return
	 * @throws RemoteException
	 * Takes the username, password, email, password and confirmPassword as inputs; these are the variables which will be used for the user registration.
	 */
	public String userRegistration(String name, String username, String email, String password, String securityQuestion, String securityAnswer) throws RemoteException;

	
	//for user log in 
	/**
	 * @author Karawugodage Don Esanda Sebastian Harshan - 1935123
	 * @param username
	 * @param password
	 * @return
	 * @throws RemoteException
	 * Takes the username and password as inputs, validates the inputs and directs/logs in the user to the system dashboard.
	 */
	public String logIn(String username, String password) throws RemoteException; 

	
	//for admin login
	/**
	 * @author Karawugodage Don Esanda Sebastian Harshan - 1935123
	 * @param username
	 * @param password
	 * @return
	 * @throws RemoteException
	 * Takes the username and password as inputs, validates the inputs and directs/logs in the admin to the system dashboard.
	 */
	public String adminLogin(String username, String password) throws RemoteException;

	
	//for user password reset
	/**
	 * @author Karawugodage Don Esanda Sebastian Harshan - 1935123
	 * @param username
	 * @param securityQuestion
	 * @param securityAnswer
	 * @return
	 * @throws RemoteException
	 * Takes the username, securityQuestion and securityAnswer as inputs and validates if a user exist, if so, he/she can proceed to resetting the password.
	 */
	public String passwordReset(String username, String securityQuestion, String securityAnswer) throws RemoteException; 

	
	//to update the new password
	/**
	 * @author Karawugodage Don Esanda Sebastian Harshan - 1935123
	 * @param username
	 * @param newPassword
	 * @return
	 * @throws RemoteException
	 * Takes the username and newPassword as inputs and updates the password in the database.
	 */
	public String updatePassword(String username, String newPassword) throws RemoteException; 

	
	/**
	 * @author Nandakumar Ashvinthan - 1935129
	 * @param type
	 * @param question1
	 * @param question2
	 * @param question3
	 * @param question4
	 * @param question5
	 * @throws RemoteException
	 * This function allows the system administrator to create a new feedback form.
	 * Six parameters are passed in this function.
	 * The feedback forms will have an unique ID which will be automatically generated.
	 * The system administrator can create a feedback form containing maximum of five questions. 
	 */
	public String createFeedback(String type, String question1, String question2, String question3, String question4, String question5) throws RemoteException;

	
	//view feedback(user) 
	/**
	 * @author Karawugodage Don Esanda Sebastian Harshan - 1935123
	 * @param filter
	 * @return
	 * @throws RemoteException
	 * Contains a parameter called filter which is used to filter the feedbacks according to the type of the feedback.
	 * An array containing all feedback forms.
	 * This function enables the user to view the available feedbacks.
	 */
	public ArrayList<FeedbackBean> viewUserFeedback(String filter) throws RemoteException;

	
	
	/**
	 * @author Nandakumar Ashvinthan - 1935129
	 * @param fid
	 * @param type
	 * @param question1
	 * @param question2
	 * @param question3
	 * @param question4
	 * @param question5
	 * @throws RemoteException
	 * This function allows the system administrator to view the feedback forms that were created.
	 * Seven parameters are passed in this function.
	 * An array containing the feedback form of the system.
	 */
	public ArrayList<FeedbackBean> viewFeedback(String fid, String type, String question1, String question2, String question3, 
			String question4, String question5) throws RemoteException;

	
	
	/**
	 * @author Nandakumar Ashvinthan - 1935129
	 * @param fid
	 * @throws RemoteException
	 * This function allows the system administrator to search for a particular feedback based on the feedback ID.
	 * Only one parameter is passed in this function.
	 */
	public FeedbackBean searchFeedback(Integer fid) throws RemoteException;
	
	
	/**
	 * @author Nandakumar Ashvinthan - 1935129
	 * @param fid
	 * @param type
	 * @param question1
	 * @param question2
	 * @param question3
	 * @param question4
	 * @param question5
	 * @throws RemoteException
	 * This function allows the system administrator to edit the questions of the feedback form if necessary.
	 * Seven parameters are passed in this function.
	 * The feedback ID and type cannot be edited.
	 */
	public String updateFeedback(Integer fid, String type, String question1, String question2, String question3, 
			String question4, String question5) throws RemoteException;

	
	
	/**
	 * @author Nandakumar Ashvinthan - 1935129
	 * @param fid
	 * @throws RemoteException
	 * This function allows the system administrator to delete a particular feedback form by searching for the respective feedback form based on the feedback ID.
	 * Only one parameter is passed in this function.
	 */
	public Integer deleteFeedback(Integer fid) throws RemoteException;

	/**
	 * @author Nandakumar Ashvinthan - 1935129
	 * @param type
	 * @throws RemoteException
	 * This function retrieves the questions of a particular feedback form from the database based on its type.
	 * Only one parameter is passed in this function.
	 */	
	public FeedbackBean getQuestions(String type) throws RemoteException;
	
	/**
	 * @author Nandakumar Ashvinthan - 1935129
	 * @param type
	 * @param question1
	 * @param question2
	 * @param question3
	 * @param question4
	 * @param question5
	 * @param feedBackID
	 * @throws RemoteException
	 * This function allows the system administrator to get the feedback from the customer. 
	 * Seven parameters are passed in this function. 
	 * The feedback gathered from the customers have a unique ID which will be automatically generated.
	 */
	public String getAnswers(String type, String question1, String question2, String question3, String question4, String question5, int feedBackID) throws RemoteException;	
	
	/**
	 * @author Muhammad Aslam - 1939084
	 * @param type
	 * @param question
	 * @param No
	 * @return
	 * @throws RemoteException
	 */
	public int getAnswerCount (String type, String question, int No) throws RemoteException;
	
}