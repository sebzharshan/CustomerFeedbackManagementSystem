package ServerSide;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class FeedbackServer {

	static int port = 1091;
	
    public static void main(String[] args) {
    	
        System.out.println("Attempting to start the Server...");
        try {
        	Registry reg = LocateRegistry.createRegistry(port); 
            Feedback feedback = new Feedback();            
            reg.rebind("Feedback", feedback); 
             								  
            System.out.println("Server started!");
            System.out.println("Welcome to Customer Feedback Management System!");             
            
        } catch (RemoteException e ) {
            System.out.println("An error occured: " +e.toString());
            e.printStackTrace();
        }
    }	
}
