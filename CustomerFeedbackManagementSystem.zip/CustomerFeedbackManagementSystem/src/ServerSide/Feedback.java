package ServerSide;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;
import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

import javax.swing.JOptionPane;

import ClientSide.Dashboard;

@SuppressWarnings("unused")
public class Feedback extends UnicastRemoteObject implements FeedbackInterface {

	private static final long serialVersionUID = -652887645123401459L;	
	
	public Feedback() throws RemoteException {
		super();
	
	}
	/**
	 * @author Karawugodage Don Esanda Sebastian Harshan - 1935123
	 * @param name 
	 * @param username
	 * @param email
	 * @param password
	 * @param securityQuestion
	 * @param securityAnwser
	 * @param password
	 * @throws RemoteException
	 * This function is used to enable users to register into the system. 
	 * Takes name, username, email, password, securityQuestion and securityAnswer as parameters.
	 * Once the user enters the information and clicks on the submit button, the details will be added to the database.
	 * This function returns the password.
	 */
	@Override
	public String userRegistration(String name, String username, String email, String password, String securityQuestion, String securityAnswer)
			throws RemoteException {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			
			SQLServerDataSource ds = new SQLServerDataSource();  
			ds.setUser("adminUser@feedback37");  
			ds.setPassword("UoB12345");  
			ds.setServerName("feedback37.database.windows.net");  
			ds.setPortNumber(1433);
			ds.setDatabaseName("feedbackDB");  
			Connection con = ds.getConnection(); 
			
			Statement stmt = con.createStatement();
			stmt.executeUpdate("Insert into [dbo].[user]([Name], [Username], [Password], [Email], [SecurityQuestion], [SecurityAnswer]) values('"+ name+"','"+username+"','"+email+"','"+password+"', '"+securityQuestion+"', '"+securityAnswer+"' )");
		}		
		catch(Exception e1){
				System.out.println(e1);
		}
		return password;
	
	}
	

	/**
	 * @author Karawugodage Don Esanda Sebastian Harshan - 1935123
	 * @param username
	 * @param password
	 * @return usernameAuth
	 * @throws RemoteException
	 * This function is used to log the user into the system.
	 * Takes the username and password as parameters, and checks the entered username and password against that of the database and if a record exist, the user will be logged into the system.
	 * This function also checks if the username and password field is empty (nothing entered by the user), if so, an error will be prompted. 
	 * This function returns the username.
	 */
	@Override
	public String logIn(String username, String password) throws RemoteException {
		
		String usernameAuth = null;
		if(username == null || username == "" || password == null || password == "") {
			return null;
		}
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			
			SQLServerDataSource ds = new SQLServerDataSource();  
			ds.setUser("adminUser@feedback37");  
			ds.setPassword("UoB12345");  
			ds.setServerName("feedback37.database.windows.net");  
			ds.setPortNumber(1433);
			ds.setDatabaseName("feedbackDB");  
			Connection con = ds.getConnection(); 
			
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("Select * from [dbo].[user] where username ='" +username + "' and Password = '" + password + " ' ");
			
			while(rs.next()) {
				usernameAuth = rs.getString(3);
				
			}
			
			stmt.close();
		}
		catch(Exception e1){
			System.out.println(e1);
	}
		return usernameAuth;
	}
	
	/**
	 * @author Karawugodage Don Esanda Sebastian Harshan - 1935123
	 * @param username
	 * @param password
	 * @return usernameAuth
	 * @throws RemoteException
	 * This function enable the Admin to log in the system.
	 * Takes the username and password as parameters, and checks the entered username and password against that of the database and if a record exist, the user will be logged into the system.
	 * This function also checks if the username and password field is empty (nothing entered by the user), if so, an error will be prompted.
	 * This function returns the username.
	 */
	public String adminLogin(String username, String password) throws RemoteException {
		
		String usernameAuth = null;
		String passwordAuth = null;
		
		if(username == null || username == "" || password == null || password == "") {
			return null;
		}
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			
			SQLServerDataSource ds = new SQLServerDataSource();  
			ds.setUser("adminUser@feedback37");  
			ds.setPassword("UoB12345");  
			ds.setServerName("feedback37.database.windows.net");  
			ds.setPortNumber(1433);
			ds.setDatabaseName("feedbackDB");  
			Connection con = ds.getConnection(); 
			
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("Select * from [dbo].[user] where username ='" +username + "' and Password = '" + password + " ' and isAdmin = 1 ");
			
			while(rs.next()) {
				usernameAuth = rs.getString(3);
				passwordAuth = rs.getString(4);
				
			}
			
		
		}
		catch(Exception e1){
			System.out.println(e1);
	}
		return usernameAuth;
	}
	

	/**
	 * @author Karawugodage Don Esanda Sebastian Harshan - 1935123
	 * @param username
	 * @param securityQuestion
	 * @param securityAnswer
	 * @return answerAuth
	 * @throws RemoteException
	 * This function takes in the username, securityQuestion and securityAnswer as parameters;
	 * the 3 details (username, securityQuestion and securityAnswer) entered by the user are checked against that of the database;
	 * if a record exist, the user can move onto the next window to reset the password.
	 * This function returns the securityAnswer
	 */
	public String passwordReset(String username, String securityQuestion, String securityAnswer) throws RemoteException{		
		
		String answerAuth = null;
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			
			SQLServerDataSource ds = new SQLServerDataSource();  
			ds.setUser("adminUser@feedback37");  
			ds.setPassword("UoB12345");  
			ds.setServerName("feedback37.database.windows.net");  
			ds.setPortNumber(1433);
			ds.setDatabaseName("feedbackDB");  
			Connection con = ds.getConnection(); 
			
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("Select * from [dbo].[user] where Username ='" +username + "' and  SecurityQuestion ='" +securityQuestion + "' and SecurityAnswer = '" + securityAnswer + " ' ");
			
			if(rs.next()) {
				answerAuth = securityAnswer;
			}
			else {
				
			}		
		}
		catch(Exception e1){
			System.out.println(e1);
		}	
		return answerAuth;
	}
	
	/**
	 * @author Karawugodage Don Esanda Sebastian Harshan - 1935123 
	 * @param username
	 * @param newPassword
	 * @return
	 * @throws RemoteException
	 * This function allows the user (Admin/user) to change their password, by entering a new password.
	 * This function takes in the username and newPassword as parameters, and the entered username is checked against that of the database;
	 * if a record exist, the new password entered by the user will be updated in the password column.
	 * This function returns the username.
	 */
	public String updatePassword(String username, String newPassword) throws RemoteException{
		
		String usernameAuth = null;
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			
			SQLServerDataSource ds = new SQLServerDataSource();  
			ds.setUser("adminUser@feedback37");  
			ds.setPassword("UoB12345");  
			ds.setServerName("feedback37.database.windows.net");  
			ds.setPortNumber(1433);
			ds.setDatabaseName("feedbackDB");  
			Connection con = ds.getConnection(); 
			
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("Update [dbo].[user] set Password = '" + newPassword + "' where Username = '" + username + "'  ");
			
			if(rs.next()) {
				usernameAuth = username;
			}
			else {
				
			}		
		}
		catch(Exception e1){
			System.out.println(e1);
		}	
		return username;
	}
	
	/**
	 * @author Nandakumar Ashvinthan - 1935129
	 * @param type Feedback Type (Electronic Products, Food, Apparel, Automotive)
	 * @param question1
	 * @param question2
	 * @param question3
	 * @param question4
	 * @param question5
	 * @throws RemoteException
	 * This function allows the system administrator to create a new feedback form.
	 * Six parameters are passed in this function.
	 * The feedback forms will have an unique ID which will be automatically generated.
	 * Maximum of five questions can be created per feedback form.
	 */
	@Override
	public String createFeedback(String type, String question1, String question2, String question3, String question4,
			String question5) throws RemoteException {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			
			SQLServerDataSource ds = new SQLServerDataSource();  
			ds.setUser("adminUser@feedback37");  
			ds.setPassword("UoB12345");  
			ds.setServerName("feedback37.database.windows.net");  
			ds.setPortNumber(1433);
			ds.setDatabaseName("feedbackDB");  
			Connection con = ds.getConnection(); 
			
			Statement stmt = con.createStatement();
			stmt.executeUpdate("Insert into [dbo].[feedback](type, question1, question2, question3, question4, question5) values('"+ type+"','"+question1+"','"+question2+"','"+question3+"', '"+question4+"', '"+question5+"')");
		}		
		catch(Exception e1){
				System.out.println(e1);
		}
		return type;
	}	
	

	/**
	 * @author Karawugodage Don Esanda Sebastian Harshan - 1935123 
	 * @param filter
	 * @return response
	 * @throws RemoteException
	 * This function fetches all the feedbacks in the database to an array and later stores them in the FeedbackBean class.
	 * The parameter 'filter' is basically the type of the feedback.
	 * The parameter 'filter' is used in the client side to display the feedback based on their type.
	 */
	public ArrayList<FeedbackBean> viewUserFeedback(String filter) throws RemoteException {
		ArrayList<FeedbackBean> response = new ArrayList<FeedbackBean>(); 
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			
			SQLServerDataSource ds = new SQLServerDataSource();  
			ds.setUser("adminUser@feedback37");  
			ds.setPassword("UoB12345");  
			ds.setServerName("feedback37.database.windows.net");  
			ds.setPortNumber(1433);
			ds.setDatabaseName("feedbackDB");  
			Connection con = ds.getConnection(); 
			
			Statement ps = con.createStatement();
			String sql = "Select * from [dbo].[feedback] where type = '" + filter + "'";
			ResultSet rs = ps.executeQuery(sql);	
			
			while(rs.next()) {
				Integer feedbackID = rs.getInt("feedbackID");
				String type_ = rs.getString("type");
				String question1_ = rs.getString("question1");
				String question2_ = rs.getString("question2");
				String question3_ = rs.getString("question3");
				String question4_ = rs.getString("question4");
				String question5_ = rs.getString("question5");
				
				response.add(new FeedbackBean(feedbackID, type_, question1_,question2_,question3_, question4_, question5_ ));
			}			
					
		}
		catch(Exception e1){
			System.out.println(e1);
	}		
		return response;
	}

	/**
	 * @author Nandakumar Ashvinthan - 1935129
	 * @param fid Feedback ID
	 * @param type Feedback Type (Electronic Products, Food, Apparel, Automotive)
	 * @param question1
	 * @param question2
	 * @param question3
	 * @param question4
	 * @param question5
	 * @throws RemoteException
	 * This function allows the system administrator to view the feedback forms that were created.
	 * Seven parameters are passed in this function.
	 * An array containing the feedback form.
	 */
	@Override
	public ArrayList<FeedbackBean> viewFeedback(String fid, String type, String question1, String question2, String question3, 
			String question4, String question5) throws RemoteException {
		ArrayList<FeedbackBean> result = new ArrayList<FeedbackBean>(); 
			try {
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				
				SQLServerDataSource ds = new SQLServerDataSource();  
				ds.setUser("adminUser@feedback37");  
				ds.setPassword("UoB12345");  
				ds.setServerName("feedback37.database.windows.net");  
				ds.setPortNumber(1433);
				ds.setDatabaseName("feedbackDB");  
				Connection conn = ds.getConnection();
				
				Statement pst = conn.createStatement();
				String vf = "select * from [dbo].[feedback]";
				ResultSet rs = pst.executeQuery(vf);
				
				while(rs.next()) {
					Integer feedbackid = rs.getInt("feedbackID");
					String ftype = rs.getString("type");
					String q1 = rs.getString("question1");
					String q2 = rs.getString("question2");
					String q3 = rs.getString("question3");
					String q4 = rs.getString("question4");
					String q5 = rs.getString("question5");
					
					result.add(new FeedbackBean(feedbackid, ftype, q1, q2, q3, q4, q5));
				}
				
			}
			catch(Exception e){
				System.out.println(e);
			}		
			return result;
	}

	/**
	 * @author Nandakumar Ashvinthan - 1935129
	 * @param fid Feedback ID
	 * @throws RemoteException 
	 * This function allows the system administrator to search for a particular feedback based on its feedback ID.
	 * Only one parameter is passed in this function.
	 */
	@Override
	public FeedbackBean searchFeedback(Integer fid) throws RemoteException {
		FeedbackBean result =  new FeedbackBean(fid, null, null, null, null, null, null);	
		
		try {
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				
				SQLServerDataSource ds = new SQLServerDataSource();  
				ds.setUser("adminUser@feedback37");  
				ds.setPassword("UoB12345");  
				ds.setServerName("feedback37.database.windows.net");  
				ds.setPortNumber(1433);
				ds.setDatabaseName("feedbackDB");  
				Connection conn = ds.getConnection();
				
				String search = "select feedbackID, type, question1, question2, question3, question4, question5 from [dbo].[feedback] where feedbackID=?";
				PreparedStatement pst = conn.prepareStatement(search);
				pst.setInt(1, fid);
				ResultSet rs = pst.executeQuery();
				
				if(rs.next()) {
					Integer feedbackid = rs.getInt("feedbackID");
					result.setFeedback_id(feedbackid);
	                
	                String ftype = rs.getString("type");
	                result.setFeedback_type(ftype);
	                
	                String q1 = rs.getString("question1");
	                result.setQuestion_1(q1);
	                
	                String q2 = rs.getString("question2");
	                result.setQuestion_2(q2);
	                
	                String q3 = rs.getString("question3");
	                result.setQuestion_3(q3);
	                
	                String q4 = rs.getString("question4");
	                result.setQuestion_4(q4);
	                
	                String q5 = rs.getString("question5");
	                result.setQuestion_5(q5);
	            }
			}		
			catch(Exception e){
					System.out.println(e);
			}
			return result;
	}

	/**
	 * @author Nandakumar Ashvinthan - 1935129
	 * @param fid Feedback ID
	 * @param type Feedback Type (Electronic Products, Food, Apparel, Automotive)
	 * @param question1
	 * @param question2
	 * @param question3
	 * @param question4
	 * @param question5
	 * @throws RemoteException
	 * This function allows the system administrator to edit the questions of the feedback form if necessary.
	 * Seven parameters are passed in this function.
	 * The feedback ID and feedback type cannot be edited.
	 */
	@Override
	public String updateFeedback(Integer fid, String type, String question1, String question2, String question3, String question4,
			String question5) throws RemoteException {
			try {
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				
				SQLServerDataSource ds = new SQLServerDataSource();  
				ds.setUser("adminUser@feedback37");  
				ds.setPassword("UoB12345");  
				ds.setServerName("feedback37.database.windows.net");  
				ds.setPortNumber(1433);
				ds.setDatabaseName("feedbackDB");  
				Connection conn = ds.getConnection();
				
				String uf = "update [dbo].[feedback] set type = '"+type+"', question1 = '"+question1+"', question2 = '"+question2+"',  question3 = '"+question3+"',  question4 = '"+question4+"', question5 = '"+question5+"' where feedbackID= '"+fid+"' ";
				PreparedStatement pst = conn.prepareStatement(uf);
				pst.execute();
			}		
			catch(Exception e){
				System.out.println(e);
			}
			return type;
	}

	/**
	 * @author Nandakumar Ashvinthan - 1935129
	 * @param fid Feedback ID
	 * @throws RemoteException
	 * This function allows the system administrator to delete a particular feedback form by searching for the respective feedback form based on its feedback ID.
	 * Only one parameter is passed in this function.
	 */
	@Override
	public Integer deleteFeedback(Integer fid) throws RemoteException {
			try {
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				
				SQLServerDataSource ds = new SQLServerDataSource();  
				ds.setUser("adminUser@feedback37");  
				ds.setPassword("UoB12345");  
				ds.setServerName("feedback37.database.windows.net");  
				ds.setPortNumber(1433);
				ds.setDatabaseName("feedbackDB");
				Connection conn = ds.getConnection();
				
				String df = "delete from [dbo].[feedback] where feedbackID=?";
	            PreparedStatement pst = conn.prepareStatement(df);
	            pst.setInt(1, fid);
	            pst.execute();
			}		
			catch(Exception e1){
				System.out.println(e1);
			}
			return fid;
	}
	
	/**
	 * @author Nandakumar Ashvinthan - 1935129
	 * @param type (Electronic Products, Food, Apparel, Automotive)
	 * @throws RemoteException
	 * This function retrieves the questions of a particular feedback form from the database based on its type.
	 * Only one parameter is passed in this function.
	 */
	@Override
	public FeedbackBean getQuestions(String type) throws RemoteException {
		FeedbackBean result =  new FeedbackBean(null, type, null, null, null, null, null);
		
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			
			SQLServerDataSource ds = new SQLServerDataSource();  
			ds.setUser("adminUser@feedback37");  
			ds.setPassword("UoB12345");  
			ds.setServerName("feedback37.database.windows.net");  
			ds.setPortNumber(1433);
			ds.setDatabaseName("feedbackDB");
			Connection conn = ds.getConnection();
			String gq = "select feedbackID, type, question1, question2, question3, question4, question5 from [dbo].[feedback] where type=?";
			PreparedStatement pst = conn.prepareStatement(gq);
			pst.setString(1, type);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
					Integer fid = rs.getInt("feedbackID");
					result.setFeedback_id(fid);
					
					String ftype = rs.getString("type");
					result.setFeedback_type(ftype);
					
	                String q1 = rs.getString("question1");
	                result.setQuestion_1(q1);
	                
	                String q2 = rs.getString("question2");
	                result.setQuestion_2(q2);
	                
	                String q3 = rs.getString("question3");
	                result.setQuestion_3(q3);
	                
	                String q4 = rs.getString("question4");
	                result.setQuestion_4(q4);
	                
	                String q5 = rs.getString("question5");
	                result.setQuestion_5(q5);
            }
		}
		catch (Exception e) {
			System.out.println(e);
		}
		return result;
	}

	/**
	 * @author Nandakumar Ashvinthan - 1935129
	 * @param type Feedback Type (Electronic Products, Food, Apparel, Automotive)
	 * @param question1
	 * @param question2
	 * @param question3
	 * @param question4
	 * @param question5
	 * @param feedBackID
	 * @throws RemoteException
	 * This function allows the system administrator to get the feedback from the customers. 
	 * Seven parameters are passed in this function. 
	 * The feedback gathered from the customers have as unique ID which will be automatically generated.
	 */
	@Override
	public String getAnswers(String type, String question1, String question2, String question3, String question4, String question5, int feedBackID) throws RemoteException {
			try {
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			
				SQLServerDataSource ds = new SQLServerDataSource();  
				ds.setUser("adminUser@feedback37");  
				ds.setPassword("UoB12345");  
				ds.setServerName("feedback37.database.windows.net");  
				ds.setPortNumber(1433);
				ds.setDatabaseName("feedbackDB");  
				Connection con = ds.getConnection(); 	
			
				Statement stmt = con.createStatement();
				stmt.executeUpdate("Insert into [dbo].[feedbackanswers](type, question1, question2, question3, question4, question5, feedbackID) values('"+ type+"','"+question1+"','"+question2+"','"+question3+"', '"+question4+"', '"+question5+"','"+feedBackID+"')");
					
				}
			catch(Exception e1){
				System.out.println(e1);
			}		
			return type;
	}

	/**
	 * @author Muhammad Aslam - 1939084
	 * @param type
	 * @param question
	 * @param No
	 * @return
	 * @throws RemoteException
	 */
	@Override
	public int getAnswerCount(String type, String question, int No) throws RemoteException {
			int count = 0;
			try {
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			
				SQLServerDataSource ds = new SQLServerDataSource();  
				ds.setUser("adminUser@feedback37");  
				ds.setPassword("UoB12345");  
				ds.setServerName("feedback37.database.windows.net");  
				ds.setPortNumber(1433);
				ds.setDatabaseName("feedbackDB");  
				Connection con = ds.getConnection(); 
			
				PreparedStatement ps = con.prepareStatement("Select count * from [dbo].[feedbackanswers]where type ='"+type+"' and question'"+No+"' = '"+question+"'");
				ResultSet rs = ps.executeQuery();
				if(rs.next()) {
					count = rs.getFetchSize();
				}
				else {
				}
			}catch(Exception e1){
				System.out.println(e1);
		}		
			return count;
	}
	
}

