package ServerSide;

import java.io.Serializable;

@SuppressWarnings("serial")
public class FeedbackBean implements Serializable {
	
	public Integer feedbackID;
	public String type;
	public String question1;
	public String question2;
	public String question3;
	public String question4;
	public String question5;
	
	public FeedbackBean(Integer feedbackID, String type, String question1, String question2, String question3, String question4,
			String question5) {
		super();
		this.feedbackID = feedbackID;
		this.type = type;
		this.question1 = question1;
		this.question2 = question2;
		this.question3 = question3;
		this.question4 = question4;
		this.question5 = question5;		
	}	
		
	public Integer getFeedback_id() {
		return feedbackID;
	}
	public void setFeedback_id(Integer feedback_id) {
		this.feedbackID = feedback_id;
	}
	public String getFeedback_type() {
		return type;
	}
	public void setFeedback_type(String feedback_type) {
		this.type = feedback_type;
	}
	public String getQuestion_1() {
		return question1;
	}
	public void setQuestion_1(String question_1) {
		this.question1 = question_1;
	}
	public String getQuestion_2() {
		return question2;
	}
	public void setQuestion_2(String question_2) {
		this.question2 = question_2;
	}
	public String getQuestion_3() {
		return question3;
	}
	public void setQuestion_3(String question_3) {
		this.question3 = question_3;
	}
	public String getQuestion_4() {
		return question4;
	}
	public void setQuestion_4(String question_4) {
		this.question4 = question_4;
	}
	public String getQuestion_5() {
		return question5;
	}
	public void setQuestion_5(String question_5) {
		this.question5 = question_5;
	}		
	
}
