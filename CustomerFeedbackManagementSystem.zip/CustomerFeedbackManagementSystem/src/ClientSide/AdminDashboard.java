package ClientSide;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

@SuppressWarnings("serial")
public class AdminDashboard extends JFrame {
	
	private JPanel contentPane;
	private JButton createFbBtn, viewFbBtn, logoutBtn, analyticsBtn;
	
	/**
	 * Create the frame.
	 */
	public AdminDashboard() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setVisible(true);
		
		createFbBtn = new JButton("Create Feedback");
		createFbBtn.setBackground(new Color(0, 191, 255));
		createFbBtn.setForeground(new Color(255, 255, 255));
		createFbBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				CreateFeedback cf = new CreateFeedback();
				cf.setVisible(true);
				dispose();
			}
		});
		createFbBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		createFbBtn.setBounds(142, 36, 170, 35);
		contentPane.add(createFbBtn);
		
		viewFbBtn = new JButton("View Feedback");
		viewFbBtn.setBackground(new Color(0, 191, 255));
		viewFbBtn.setForeground(new Color(255, 255, 255));
		viewFbBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ViewFeedback vf = new ViewFeedback();
				vf.setVisible(true);
				dispose();
			}
		});
		viewFbBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		viewFbBtn.setBounds(142, 84, 170, 35);
		contentPane.add(viewFbBtn);
		
		logoutBtn = new JButton("Log Out");
		logoutBtn.setBackground(new Color(0, 191, 255));
		logoutBtn.setForeground(new Color(255, 255, 255));
		logoutBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				AdminLogin al = new AdminLogin();
				al.setVisible(true);
				dispose();
			}
		});
		logoutBtn.setBounds(12, 12, 80, 25);
		contentPane.add(logoutBtn);
		
		analyticsBtn = new JButton("Feedback Analytics");
		analyticsBtn.setBackground(new Color(0, 191, 255));
		analyticsBtn.setForeground(new Color(255, 255, 255));
		analyticsBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ViewAnalytics va = new ViewAnalytics();
				va.setVisible(true);
				dispose();
			}
		});
		analyticsBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		analyticsBtn.setBounds(142, 132, 170, 35);
		contentPane.add(analyticsBtn);
	}
	
}
