package ClientSide;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import ServerSide.Feedback;
import ServerSide.FeedbackInterface;

import java.sql.*;
import java.util.HashMap;

@SuppressWarnings({ "serial", "unused" })
public class SignIn extends JFrame implements ActionListener {

	JTextArea username, password, newUser;
	JTextField userName, pass;
	JButton signIn, signUp , back, forgotPassword;
	JPanel panel;
	static int port = 1091;
	String ipAddress = "192.168.1.100";

	public SignIn() {
		//setLayout(new BorderLayout()); 		 // run and see how it turns out
		setLayout(new FlowLayout());
		setDefaultCloseOperation(EXIT_ON_CLOSE); //(1)
		setSize(400, 400);					  	 //(2)
		setVisible(true); 						 //(3)
		setTitle("Sign In");					 //use this order: 1, 2, 3 to open the application without resizing
		
		username = new JTextArea("Username:");
		password = new JTextArea("Password:");
		//forgotPassword = new JTextArea("Forgot Password?");
		newUser = new JTextArea("Not a user? Sign up!");
		
		userName = new JTextField();
		userName.setToolTipText("Enter your name");
		pass = new JTextField();
		pass.setToolTipText("Enter your password");
		
		signIn = new JButton("Sign In");
		signIn.setBackground(new Color(0, 191, 255));
		signIn.setForeground(new Color(255, 255, 255));
		
		//User authentication database stuff 
		signIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String a = userName.getText().toString();
					String b = pass.getText().toString();
					
					if(a == null || a.isEmpty() || b == null || b.isEmpty()) {
						//User is not valid
						JOptionPane.showMessageDialog(null, "Empty! Please enter your credentials!");
					}
					else {
						//user is valid
						Registry myReg = LocateRegistry.getRegistry(ipAddress, port); //1
						FeedbackInterface Feedback = (FeedbackInterface)myReg.lookup("Feedback");//2
						//FeedbackInterface Feedback = (FeedbackInterface)Naming.lookup("rmi://localhost:1078/Feedback");
						String response = Feedback.logIn(a, b);	
						
							if(response == null || response.isEmpty()) {
								JOptionPane.showMessageDialog(null, "Invalid User!");
							}
							else {
								JOptionPane.showMessageDialog(null, "Welcome, "+ response+"!" + " You have logged in successfully.");	
								new Dashboard();						
								dispose();
							}
					}
				} 
				catch (RemoteException | NotBoundException e1) {
				e1.printStackTrace();

				}	
			}
	 	}); 
		
		signUp = new JButton("Sign up!");
		signUp.setBackground(new Color(0, 191, 255));
		signUp.setForeground(new Color(255, 255, 255));
		
		back = new JButton();
		back.setBackground(new Color(0, 191, 255));
		back.setForeground(new Color(255, 255, 255));
		Image backImage = new ImageIcon(this.getClass().getResource("/back2.png")).getImage();
		back.setIcon(new ImageIcon(backImage));	
		
		forgotPassword = new JButton(("Forgot Password?"));
		forgotPassword.setBackground(new Color(0, 191, 255));
		forgotPassword.setForeground(new Color(255, 255, 255));
		
		Box box = Box.createVerticalBox();
		box.add(back);
		box.add(Box.createVerticalStrut(30));
		box.add(username);
		box.add(Box.createVerticalStrut(5));
		box.add(userName);
		box.add(Box.createVerticalStrut(5));
		box.add(password);
		box.add(pass);
		box.add(Box.createVerticalStrut(10));
		box.add(signIn);
		box.add(Box.createVerticalStrut(25));
		//box.add(forgotPassword);
		box.add(Box.createVerticalStrut(25));
		box.add(newUser);
		box.add(Box.createVerticalStrut(5));
		box.add(signUp);
		box.add(Box.createVerticalStrut(30));
		box.add(forgotPassword);		

		add(box);
		
		signUp.addActionListener(this);
		signIn.addActionListener(this);
		back.addActionListener(this);
		forgotPassword.addActionListener(this);

	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(signUp)) {
			new SignUp();
			this.dispose();
		} else if(e.getSource().equals(signIn)) {
			//new Dashboard();
			//this.dispose();
		} else if(e.getSource().equals(back)) {
			new StartUI();
			this.dispose();
		} else if(e.getSource().equals(forgotPassword)){
			new ForgotPassword();
			this.dispose();
		}
		else {
			
		}
	}

}

 