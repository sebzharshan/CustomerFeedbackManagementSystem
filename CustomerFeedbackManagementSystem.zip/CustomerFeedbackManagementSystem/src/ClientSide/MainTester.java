package ClientSide;

public class MainTester {

	@SuppressWarnings("unused")
	public static void main(String[] args){

		StartUI obj1 = new StartUI();
		//SignIn ob2 = new SignIn();
		//SignUp ob3 = new SignUp();
		//Dashboard ob4 = new Dashboard();
		//AdminLogin ob5 = new AdminLogin();
		//AdminDashboard ob6 = new AdminDashboard();
		//CreateFeedback ob7 = new CreateFeedback();
		//UserViewFeedback ob8 = new UserViewFeedback();
		//ForgotPassword ob9 = new ForgotPassword();
		//ResetPassword ob10 = new ResetPassword();
		//AccountSettings ob11 = new AccountSettings();
		
	}

}
