package ClientSide;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;


@SuppressWarnings("serial")
public class Dashboard extends JFrame implements ActionListener{

	JButton electronic, food, apparel, automotive, entertainment, logout;
	
	public Dashboard() {
		setLayout(new FlowLayout());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(400, 400);
		setVisible(true);
		setTitle("Dashboard");
				
		electronic = new JButton("Electronic Items");      //these spaces were set to temporarily adjust all button to the same length
		electronic.setBackground(new Color(0, 191, 255));
		electronic.setForeground(new Color(255, 255, 255));
		
		food = new JButton("Food                      "); 
		food.setBackground(new Color(0, 191, 255));
		food.setForeground(new Color(255, 255, 255));
		
		apparel = new JButton("Apparel                ");
		apparel.setBackground(new Color(0, 191, 255));
		apparel.setForeground(new Color(255, 255, 255));
		
		automotive = new JButton("Automotive         ");
		automotive.setBackground(new Color(0, 191, 255));
		automotive.setForeground(new Color(255, 255, 255));
		
		entertainment = new JButton("Entertainment    ");
		entertainment.setBackground(new Color(0, 191, 255));
		entertainment.setForeground(new Color(255, 255, 255));

		logout = new JButton();
		logout.setBackground(new Color(0, 191, 255));
		logout.setForeground(new Color(255, 255, 255));
		Image logoutImage = new ImageIcon(this.getClass().getResource("/logout.png")).getImage();
		logout.setIcon(new ImageIcon(logoutImage));	
		
		Box box = Box.createVerticalBox();
		box.add(logout);
		box.add(Box.createVerticalStrut(30));
		box.add(electronic);
		box.add(Box.createVerticalStrut(5));
		box.add(food);
		box.add(Box.createVerticalStrut(5));
		box.add(apparel);
		box.add(Box.createVerticalStrut(5));
		box.add(automotive);
		box.add(Box.createVerticalStrut(10));
		
		add(box);
		electronic.addActionListener(this);
		food.addActionListener(this);
		apparel.addActionListener(this);
		automotive.addActionListener(this);
		entertainment.addActionListener(this);
		logout.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(electronic)) {
			new UserViewFeedback("Electronic Products");
			this.dispose();
		}
		else if(e.getSource().equals(food)){
			new UserViewFeedback("Food");
			this.dispose();
		}
		else if(e.getSource().equals(apparel)){
			new UserViewFeedback("Apparel");
			this.dispose();
		}
		else if(e.getSource().equals(automotive)){
			new UserViewFeedback("Automotive");
			this.dispose();
		}
		else if(e.getSource().equals(entertainment)){
			new UserViewFeedback("Entertainment");
			this.dispose();
		}
		else if(e.getSource().equals(logout)){
			new SignIn();
			this.dispose();
		}
	}
	
}
