package ClientSide;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import ServerSide.FeedbackInterface;
import ServerSide.Feedback;

@SuppressWarnings({ "serial", "unused" })
public class UserViewFeedback extends JFrame implements ActionListener{

	JTable viewTable;
	JScrollPane viewPane;
	JButton load, back, gqBtn;
	DefaultTableModel dtm;
	static int port = 1091;
	String ipAddress = "192.168.1.100";

	public UserViewFeedback(String type) {
		
		setLayout(new FlowLayout());
		setDefaultCloseOperation(EXIT_ON_CLOSE); 
		setSize(800, 630);					  	 
		setVisible(true); 						 
		setTitle("View Feedback");		
		
		
		String[] columnNames = {"Type", "Question1", "Question2", "Question3", "Question4", "Question5"};
		
		Object[] [] data = {
				
		};
		
		dtm = new DefaultTableModel(data, columnNames);
		viewTable = new JTable(dtm);
		viewTable.setPreferredScrollableViewportSize(new Dimension(550, 400));
		viewTable.setFillsViewportHeight(true);
		viewTable.setBounds(50,50,50,50);
		
		//row height
		viewTable.setRowHeight(30);
		
		//column width
		TableColumnModel tcm = viewTable.getColumnModel();
		tcm.getColumn(0).setPreferredWidth(50);
		tcm.getColumn(1).setPreferredWidth(50);
		tcm.getColumn(2).setPreferredWidth(50);
		tcm.getColumn(3).setPreferredWidth(200);
		tcm.getColumn(4).setPreferredWidth(200);
		tcm.getColumn(5).setPreferredWidth(200);		
		
		viewPane = new JScrollPane(viewTable);
		
		back = new JButton("Back");
		back.setBackground(new Color(0, 191, 255));
		back.setForeground(new Color(255, 255, 255));
		
		load = new JButton("View Available Feedbacks");
		load.setBackground(new Color(0, 191, 255));
		load.setForeground(new Color(255, 255, 255));
		
		//view feedback database stuff
		load.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Registry myReg = LocateRegistry.getRegistry(ipAddress, port); 
					FeedbackInterface Feedback = (FeedbackInterface)myReg.lookup("Feedback");
					ArrayList<ServerSide.FeedbackBean> response = Feedback.viewUserFeedback(type);
					DefaultTableModel dtm = (DefaultTableModel)viewTable.getModel();
		
					for(ServerSide.FeedbackBean feedback: response) {						
						Object obj[] = {feedback.type, feedback.question1, feedback.question2, feedback.question3, feedback.question4, feedback.question5};
						dtm.addRow(obj);
					
					}					
				}catch(Exception e1){
					e1.printStackTrace();
				}
			}
		});
		
		gqBtn = new JButton("Answer Questionnaire");
		gqBtn.setBackground(new Color(0, 191, 255));
		gqBtn.setForeground(new Color(255, 255, 255));
		
		gqBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if(type == "Electronic Products") {
					GetAnswers ga = new GetAnswers("Electronic Products");
					ga.setVisible(true);
					dispose();
				}
				else if(type == "Food") {
					GetAnswers ga = new GetAnswers("Food");
					ga.setVisible(true);
					dispose();
				}
				else if(type == "Apparel") {
					GetAnswers ga = new GetAnswers("Apparel");
					ga.setVisible(true);
					dispose();
				}
				else if(type == "Automotive") {
					GetAnswers ga = new GetAnswers("Automotive");
					ga.setVisible(true);
					dispose();
				}
			}
		});
		//gqBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		gqBtn.setBounds(12, 13, 97, 25);

		Box box = Box.createVerticalBox();
		box.add(Box.createVerticalStrut(30));
		box.add(viewPane);
		box.add(Box.createVerticalStrut(10));
		box.add(back);
		box.add(Box.createVerticalStrut(10));
		box.add(load);
		box.add(Box.createVerticalStrut(10));
		box.add(gqBtn);
		
		//add(viewPane);
		//add(load);
		//add(back);
		add(box);
		
		back.addActionListener(this);
		gqBtn.addActionListener(this);
		
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(back)) {
			new Dashboard();
			dispose();
		}
		else {
			
		}
	}
	
}