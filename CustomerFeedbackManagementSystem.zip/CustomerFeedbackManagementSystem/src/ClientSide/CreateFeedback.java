package ClientSide;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
//import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import ServerSide.FeedbackInterface;

@SuppressWarnings("serial")
public class CreateFeedback extends JFrame {

	private JPanel contentPane;
	private JTextField q1Field;
	private JTextField q2Field;
	private JTextField q3Field;
	private JTextField q4Field;
	private JTextField q5Field;
	static int port = 1091;
	String ipAddress = "192.168.1.100";

	/**
	 * Create the frame.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public CreateFeedback() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 334);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setTitle("Create Feedback");
		
		JComboBox ftComboBox = new JComboBox();
		ftComboBox.setModel(new DefaultComboBoxModel(new String[] {"Electronic Products", "Food", "Apparel", "Automotive"}));
		ftComboBox.setBounds(215, 13, 175, 22);
		contentPane.add(ftComboBox);
		
		q1Field = new JTextField();
		q1Field.setBounds(215, 48, 175, 22);
		contentPane.add(q1Field);
		q1Field.setColumns(10);
		
		q2Field = new JTextField();
		q2Field.setBounds(215, 83, 175, 22);
		contentPane.add(q2Field);
		q2Field.setColumns(10);
		
		q3Field = new JTextField();
		q3Field.setBounds(215, 118, 175, 22);
		contentPane.add(q3Field);
		q3Field.setColumns(10);
		
		q4Field = new JTextField();
		q4Field.setBounds(215, 153, 175, 22);
		contentPane.add(q4Field);
		q4Field.setColumns(10);
		
		q5Field = new JTextField();
		q5Field.setBounds(215, 188, 175, 22);
		contentPane.add(q5Field);
		q5Field.setColumns(10);
		
		JLabel ftLabel = new JLabel("Feedback Type:");
		ftLabel.setBounds(102, 13, 101, 22);
		contentPane.add(ftLabel);
		
		JLabel q1Label = new JLabel("Question 1:");
		q1Label.setBounds(102, 48, 101, 22);
		contentPane.add(q1Label);
		
		JLabel q2Label = new JLabel("Question 2:");
		q2Label.setBounds(102, 83, 101, 22);
		contentPane.add(q2Label);
		
		JLabel q3Label = new JLabel("Question 3:");
		q3Label.setBounds(102, 118, 101, 22);
		contentPane.add(q3Label);
		
		JLabel q4Label = new JLabel("Question 4:");
		q4Label.setBounds(102, 153, 101, 22);
		contentPane.add(q4Label);
		
		JLabel q5Label = new JLabel("Question 5:");
		q5Label.setBounds(102, 188, 101, 16);
		contentPane.add(q5Label);
		
		JButton createBtn = new JButton("Create");
		createBtn.setBackground(new Color(0, 191, 255));
		createBtn.setForeground(new Color(255, 255, 255));
		
		createBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String fType = ftComboBox.getSelectedItem().toString();
				String q1 = q1Field.getText();
				String q2 = q2Field.getText();
				String q3 = q3Field.getText();
				String q4 = q4Field.getText();
				String q5 = q5Field.getText();
				
				try {
		            //FeedbackInterface fi = (FeedbackInterface)Naming.lookup("rmi://localhost:1099/Feedback");
					Registry myReg = LocateRegistry.getRegistry(ipAddress, port); //1
					FeedbackInterface Feedback = (FeedbackInterface)myReg.lookup("Feedback");
		            @SuppressWarnings("unused")
					String result = Feedback.createFeedback(fType, q1, q2, q3, q4, q5);
		            JOptionPane.showMessageDialog(null, "Data added successfully");
		            AdminDashboard ad = new AdminDashboard();
		            ad.setVisible(true);
		            dispose();
		        }

		        catch(Exception e) {
		            JOptionPane.showMessageDialog(null, "Error");
		            e.printStackTrace();
		        }	
			}
		});
		createBtn.setBounds(257, 249, 97, 25);
		contentPane.add(createBtn);
		
		JButton backBtn = new JButton("Back");
		backBtn.setBackground(new Color(0, 191, 255));
		backBtn.setForeground(new Color(255, 255, 255));
		backBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				AdminDashboard ad = new AdminDashboard();
				ad.setVisible(true);
				dispose();
			}
		});
		backBtn.setBounds(12, 12, 65, 25);
		contentPane.add(backBtn);
		
	}
}
