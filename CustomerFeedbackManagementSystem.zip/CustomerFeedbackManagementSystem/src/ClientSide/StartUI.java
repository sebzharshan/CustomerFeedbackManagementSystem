package ClientSide;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;




@SuppressWarnings("serial")
public class StartUI extends JFrame implements ActionListener {

	JButton admin, user;
	String confirmed_val, recovered_val, deaths_val, active_val, date_val;
	JLabel confirmedL, recoveredL, deathsL, activeL, dateL, reminderL, infoL, infoL1, infoL2;
	CovidData cdata= new CovidData();

	CovidData obj = cdata.consumeApi(cdata);
	public StartUI() {
	setLayout(new FlowLayout());
	setVisible(true);
	setSize(400, 400);
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	setTitle("Welcome!");
	
	admin = new JButton("Admin");
	admin.setBackground(new Color(0, 191, 255));
	admin.setForeground(new Color(255, 255, 255));
	//admin.setAlignmentX(CENTER_ALIGNMENT);
	user = new JButton("User   ");
	user.setBackground(new Color(0, 191, 255));
	user.setForeground(new Color(255, 255, 255)); //resize the buttons
	//user.setAlignmentX(CENTER_ALIGNMENT);
	
	confirmedL = new JLabel("Confirmed Cases :"+ obj.getConfirmed());
	recoveredL = new JLabel("Recovered Cases :"+ obj.getRecovered());
	activeL = new JLabel("Active Cases :"+ obj.getActive());
	deathsL = new JLabel("Confirmed Deaths :"+ obj.getDeaths());
	dateL = new JLabel("Last Recorded Date :"+ obj.getDate());
	reminderL = new JLabel("Reminder !!");
	reminderL.setForeground(Color.RED);
	infoL = new JLabel("Please be careful during pandemic.");
	infoL1 = new JLabel("Stay safe at home.");
	infoL2 = new JLabel("Here's the current stat of covid-19 pandemic");
	
	
	Box box = Box.createVerticalBox();
	box.add(Box.createVerticalStrut(50));
	box.add(admin);
	box.add(Box.createVerticalStrut(5));
	box.add(user);
	box.add(Box.createVerticalStrut(20));
	box.add(reminderL);
	box.add(Box.createVerticalStrut(5));
	box.add(infoL);
	box.add(Box.createVerticalStrut(5));
	box.add(infoL1);
	box.add(Box.createVerticalStrut(10));
	box.add(Box.createVerticalStrut(5));
	box.add(infoL2);
	box.add(activeL);
	box.add(Box.createVerticalStrut(5));
	box.add(confirmedL);
	box.add(Box.createVerticalStrut(5));
	box.add(confirmedL);
	box.add(Box.createVerticalStrut(5));
	box.add(deathsL);
	box.add(Box.createVerticalStrut(5));
	box.add(recoveredL);
	box.add(Box.createVerticalStrut(5));
	box.add(dateL);
	add(box);
    	
	admin.addActionListener(this);
	user.addActionListener(this);

	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(user)) {
			new SignIn();
			this.dispose();
		} else if(e.getSource().equals(admin)) {
			new AdminLogin();
			this.dispose();
		}
		else {
			
		}
	}
}
