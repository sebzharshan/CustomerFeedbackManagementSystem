package ClientSide;

import java.io.IOException;

import org.codehaus.jackson.annotate.JsonProperty;
import org.json.JSONObject;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class CovidData {
	//Mapping Json data to variables
	@JsonProperty("confirmed")    private String confirmed;
	@JsonProperty("recovered")    private String recovered;
	@JsonProperty("deaths")       private String deaths;
	@JsonProperty("active")       private String active;
	@JsonProperty("date")         private String date;
	
	public String getConfirmed() {
		return confirmed;
	}

	public void setConfirmed(String confirmed) {
		this.confirmed = confirmed;
	}

	public String getRecovered() {
		return recovered;
	}

	public void setRecovered(String recovered) {
		this.recovered = recovered;
	}

	public String getDeaths() {
		return deaths;
	}

	public void setDeaths(String deaths) {
		this.deaths = deaths;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public OkHttpClient getClient() {
		return client;
	}

	public void setClient(OkHttpClient client) {
		this.client = client;
	}
	
//Method to consume API
//Source => https://square.github.io/okhttp/
OkHttpClient client = new OkHttpClient();
	
	String run(String url) throws IOException {
	Request request = new Request.Builder()
			.url(url)
			.get()
			.addHeader("x-rapidapi-host", "covid-19-data.p.rapidapi.com")
			.addHeader("x-rapidapi-key", "17b59de7e4msh75d3d6cb8a0a7d1p137ac4jsn521b6bdbb4d6")
			.build();

	try (
		Response response = client.newCall(request).execute()){
		return response.body().string();
	}
			
}
	//This method consumes the API and stores in CovidData class as an object
	//Source => https://rapidapi.com/Gramzivi/api/covid-19-data?endpoint=apiendpoint_cf19755e-dd5a-4723-9eb9-a2b87d824002
	public CovidData consumeApi(CovidData data) {
		try {
			String response = run("https://covid-19-data.p.rapidapi.com/report/totals?date-format=YYYY-MM-DD&format=json&date=2020-05-01");
			
			//removes the square brackets from the string value obtained
			//Source => https://stackoverflow.com/questions/16576983/replace-multiple-characters-in-one-replace-call
			String jsonFormattedString = response.replace("[","").replace("]", "");
			JSONObject json = new JSONObject(jsonFormattedString);
			
			//Mapping json value to variables
			String confirmed = json.get("confirmed").toString();
			setConfirmed(confirmed);

			String recovered = json.get("recovered").toString();
			setRecovered(recovered);

			String deaths = json.get("deaths").toString();
			setDeaths(deaths);
			String active = json.get("active").toString();
			setActive(active);

			String date = json.get("date").toString();
			setDate(date);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
	}

	

	
	
	
}






