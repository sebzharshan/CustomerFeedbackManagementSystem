package ClientSide;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import ServerSide.FeedbackBean;
import ServerSide.FeedbackInterface;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

@SuppressWarnings("serial")
public class GetAnswers extends JFrame {

	private JPanel contentPane;
	private JTextField q1Field;
	private JTextField q2Field;
	private JTextField q3Field;
	private JTextField q4Field;
	private JTextField q5Field;
	private JTextField ftypeField;
	private JTextField fidField;
	private JTextField a3Field;
	static int port = 1091;
	String ipAddress = "192.168.1.100";

	/**
	 * Create the frame.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public GetAnswers(String type) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 652, 580);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		q1Field = new JTextField();
		q1Field.setEditable(false);
		q1Field.setFont(new Font("Tahoma", Font.PLAIN, 15));
		q1Field.setBounds(157, 122, 326, 22);
		contentPane.add(q1Field);
		q1Field.setColumns(10);
		
		q2Field = new JTextField();
		q2Field.setEditable(false);
		q2Field.setFont(new Font("Tahoma", Font.PLAIN, 15));
		q2Field.setBounds(157, 192, 326, 22);
		contentPane.add(q2Field);
		q2Field.setColumns(10);
		
		q3Field = new JTextField();
		q3Field.setEditable(false);
		q3Field.setFont(new Font("Tahoma", Font.PLAIN, 15));
		q3Field.setBounds(157, 262, 326, 22);
		contentPane.add(q3Field);
		q3Field.setColumns(10);
		
		q4Field = new JTextField();
		q4Field.setEditable(false);
		q4Field.setFont(new Font("Tahoma", Font.PLAIN, 15));
		q4Field.setBounds(157, 332, 326, 22);
		contentPane.add(q4Field);
		q4Field.setColumns(10);
		
		q5Field = new JTextField();
		q5Field.setEditable(false);
		q5Field.setFont(new Font("Tahoma", Font.PLAIN, 15));
		q5Field.setBounds(157, 402, 326, 22);
		contentPane.add(q5Field);
		q5Field.setColumns(10);
		
		JComboBox a1Box = new JComboBox();
		a1Box.setFont(new Font("Tahoma", Font.PLAIN, 15));
		a1Box.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5"}));
		a1Box.setBounds(157, 157, 192, 22);
		contentPane.add(a1Box);
		
		JComboBox a2Box = new JComboBox();
		a2Box.setFont(new Font("Tahoma", Font.PLAIN, 15));
		a2Box.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5"}));
		a2Box.setBounds(157, 227, 192, 22);
		contentPane.add(a2Box);
		
		JComboBox a3Box = new JComboBox();
		a3Box.setFont(new Font("Tahoma", Font.PLAIN, 15));
		a3Box.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5"}));
		a3Box.setBounds(157, 297, 326, 22);
		contentPane.add(a3Box);
		
		JComboBox a4Box = new JComboBox();
		a4Box.setFont(new Font("Tahoma", Font.PLAIN, 15));
		a4Box.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5"}));
		a4Box.setBounds(157, 367, 192, 22);
		contentPane.add(a4Box);
		
		JComboBox a5Box = new JComboBox();
		a5Box.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5"}));
		a5Box.setFont(new Font("Tahoma", Font.PLAIN, 15));
		a5Box.setBounds(157, 437, 192, 22);
		contentPane.add(a5Box);
		
		JButton submitBtn = new JButton("Submit");
		submitBtn.setBackground(new Color(0, 191, 255));
		submitBtn.setForeground(new Color(255, 255, 255));
		
		submitBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Integer fid = Integer.parseInt(fidField.getText());
				String fType = ftypeField.getText();
				String a1 = a1Box.getSelectedItem().toString();
				String a2 = a2Box.getSelectedItem().toString();
				String a3 = a3Field.getText();
				String a4 = a4Box.getSelectedItem().toString();
				String a5 = a5Box.getSelectedItem().toString();
				
				try {
					Registry myReg = LocateRegistry.getRegistry(ipAddress, port);
					FeedbackInterface Feedback = (FeedbackInterface)myReg.lookup("Feedback");
		            @SuppressWarnings("unused")
					String result = Feedback.getAnswers(fType, a1, a2, a3, a4, a5, fid);
		            JOptionPane.showMessageDialog(null, "Answers successfully submitted.");
		            //UserViewFeedback uvf = new UserViewFeedback("");
		            Dashboard uvf = new Dashboard();
		            uvf.setVisible(true);
		            dispose();
		        }
		        catch(Exception e) {
		            JOptionPane.showMessageDialog(null, "Error");
		            e.printStackTrace();
		        }	
			}
		});
		
		submitBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		submitBtn.setBounds(290, 495, 97, 25);
		contentPane.add(submitBtn);
		
		JButton loadBtn = new JButton("Load");
		loadBtn.setBackground(new Color(0, 191, 255));
		loadBtn.setForeground(new Color(255, 255, 255));
		
		loadBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Registry myReg = LocateRegistry.getRegistry(ipAddress, port);
					FeedbackInterface Feedback = (FeedbackInterface)myReg.lookup("Feedback");
		            FeedbackBean  response = Feedback.getQuestions(type);
		                                 
		            fidField.setText(response.getFeedback_id().toString());	
		            ftypeField.setText(response.getFeedback_type());
		            q1Field.setText(response.getQuestion_1());
		            q2Field.setText(response.getQuestion_2());
		            q3Field.setText(response.getQuestion_3());
		            q4Field.setText(response.getQuestion_4());
		            q5Field.setText(response.getQuestion_5());
				}
				catch (Exception e) {
					System.out.println(e);
				}
			}
		});
		loadBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		loadBtn.setBounds(525, 13, 97, 25);
		contentPane.add(loadBtn);
		
		JButton backBtn = new JButton("Back");
		backBtn.setBackground(new Color(0, 191, 255));
		backBtn.setForeground(new Color(255, 255, 255));
		
		backBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				UserViewFeedback uh = new UserViewFeedback(type);
				uh.setVisible(true);
				dispose();
			}
		});
		backBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		backBtn.setBounds(12, 13, 97, 25);
		contentPane.add(backBtn);
		
		ftypeField = new JTextField();
		ftypeField.setHorizontalAlignment(SwingConstants.CENTER);
		ftypeField.setEditable(false);
		ftypeField.setFont(new Font("Tahoma", Font.PLAIN, 15));
		ftypeField.setBounds(157, 87, 326, 22);
		contentPane.add(ftypeField);
		ftypeField.setColumns(10);
		
		fidField = new JTextField();
		fidField.setHorizontalAlignment(SwingConstants.CENTER);
		fidField.setEditable(false);
		fidField.setFont(new Font("Tahoma", Font.PLAIN, 15));
		fidField.setBounds(157, 52, 326, 22);
		contentPane.add(fidField);
		fidField.setColumns(10);
		
		a3Field = new JTextField();
		a3Field.setBounds(157, 297, 326, 22);
		contentPane.add(a3Field);
		a3Field.setColumns(10);
	}
}
