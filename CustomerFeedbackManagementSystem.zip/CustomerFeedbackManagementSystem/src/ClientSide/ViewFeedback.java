package ClientSide;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
//import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;

import ServerSide.FeedbackInterface;
import ServerSide.FeedbackBean;

@SuppressWarnings("serial")
public class ViewFeedback extends JFrame {

	JPanel contentPane;
	JTable table;
	DefaultTableModel dtm;
	JTextField searchField;
	JTextField fidField;
	JTextField ftField;
	JTextField q1Field;
	JTextField q2Field;
	JTextField q3Field;
	JTextField q4Field;
	JTextField q5Field;	
	static int port = 1091;
	String ipAddress = "192.168.1.100";

	/**
	 * Create the frame.
	 */
	public ViewFeedback() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1336, 506);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(12, 51, 1294, 198);
		contentPane.add(scrollPane);
		
		String[] colNames = {"Feedback ID", "Feedback Type", "Question 1", "Question 2", "Question 3", "Question 4", "Question 5"}; 
		Object[] [] data = {};
		
		DefaultTableModel dtm = new DefaultTableModel(data, colNames);
		table = new JTable(dtm);
		table.setPreferredScrollableViewportSize(new Dimension(550, 400));
		table.setFillsViewportHeight(true);
		table.setBounds(50, 50, 50, 50);
		scrollPane.setViewportView(table);
		
		table.setRowHeight(15);
		
		TableColumnModel tcm = table.getColumnModel();
		tcm.getColumn(0).setPreferredWidth(50);
		tcm.getColumn(1).setPreferredWidth(50);
		tcm.getColumn(2).setPreferredWidth(50);
		tcm.getColumn(3).setPreferredWidth(50);
		tcm.getColumn(4).setPreferredWidth(50);
		tcm.getColumn(5).setPreferredWidth(50);
		tcm.getColumn(6).setPreferredWidth(50);
		
		JButton ldBtn = new JButton("Load Data");
		ldBtn.setBackground(new Color(0, 191, 255));
		ldBtn.setForeground(new Color(255, 255, 255));		
		ldBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		ldBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					
				}
				catch(Exception e) {
					e.printStackTrace();
				}
			}
		});
		ldBtn.setBounds(1190, 13, 116, 25);
		contentPane.add(ldBtn);
		
		JButton backBtn = new JButton("Back");
		backBtn.setBackground(new Color(0, 191, 255));
		backBtn.setForeground(new Color(255, 255, 255));
		backBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				AdminDashboard ad = new AdminDashboard();
				ad.setVisible(true);
				dispose();
			}
		});
		backBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		backBtn.setBounds(12, 13, 97, 25);
		contentPane.add(backBtn);
		
		searchField = new JTextField();
		searchField.setFont(new Font("Tahoma", Font.PLAIN, 15));
		searchField.setBounds(12, 262, 116, 25);
		contentPane.add(searchField);
		searchField.setColumns(10);
		
		JButton searchBtn = new JButton("Search");
		searchBtn.setBackground(new Color(0, 191, 255));
		searchBtn.setForeground(new Color(255, 255, 255));
		searchBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Integer fid = Integer.parseInt(searchField.getText());
					//FeedbackInterface fi = (FeedbackInterface)Naming.lookup("rmi://localhost:1099/Feedback");
					Registry myReg = LocateRegistry.getRegistry(ipAddress, port);
					FeedbackInterface Feedback = (FeedbackInterface)myReg.lookup("Feedback");					
					FeedbackBean  response = Feedback.searchFeedback(fid);
					
					fidField.setText(response.getFeedback_id().toString());		            
	                ftField.setText(response.getFeedback_type());	                
	                q1Field.setText(response.getQuestion_1());
	                q2Field.setText(response.getQuestion_2());
	                q3Field.setText(response.getQuestion_3());
	                q4Field.setText(response.getQuestion_4());
	                q5Field.setText(response.getQuestion_5());     
		        }
		        catch(Exception e) {
		            JOptionPane.showMessageDialog(null, "Error");
		            e.printStackTrace();
		        }
			}
		});
		searchBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		searchBtn.setBounds(140, 262, 97, 25);
		contentPane.add(searchBtn);
		
		JLabel fidLabel = new JLabel("Feedback ID:");
		fidLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		fidLabel.setBounds(305, 262, 106, 25);
		contentPane.add(fidLabel);
		
		JLabel ftypeLabel = new JLabel("Feedback Type:");
		ftypeLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		ftypeLabel.setBounds(305, 300, 106, 25);
		contentPane.add(ftypeLabel);
		
		JLabel q1Label = new JLabel("Question 1:");
		q1Label.setFont(new Font("Tahoma", Font.PLAIN, 15));
		q1Label.setBounds(305, 338, 106, 25);
		contentPane.add(q1Label);
		
		JLabel q2Label = new JLabel("Question 2:");
		q2Label.setFont(new Font("Tahoma", Font.PLAIN, 15));
		q2Label.setBounds(305, 376, 106, 25);
		contentPane.add(q2Label);
		
		fidField = new JTextField();
		fidField.setEditable(true);
		fidField.setFont(new Font("Tahoma", Font.PLAIN, 15));
		fidField.setBounds(423, 263, 185, 24);
		contentPane.add(fidField);
		fidField.setColumns(10);
		
		ftField = new JTextField();
		ftField.setEditable(true);
		ftField.setFont(new Font("Tahoma", Font.PLAIN, 15));
		ftField.setBounds(423, 302, 185, 23);
		contentPane.add(ftField);
		ftField.setColumns(10);
		
		q1Field = new JTextField();
		q1Field.setFont(new Font("Tahoma", Font.PLAIN, 15));
		q1Field.setBounds(423, 340, 185, 23);
		contentPane.add(q1Field);
		q1Field.setColumns(10);
		
		q2Field = new JTextField();
		q2Field.setFont(new Font("Tahoma", Font.PLAIN, 15));
		q2Field.setBounds(423, 378, 185, 23);
		contentPane.add(q2Field);
		q2Field.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Question 3:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(305, 414, 106, 25);
		contentPane.add(lblNewLabel);
		
		q3Field = new JTextField();
		q3Field.setBounds(423, 416, 185, 23);
		contentPane.add(q3Field);
		q3Field.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Question 4:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(650, 262, 106, 25);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Question 5:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(650, 300, 106, 25);
		contentPane.add(lblNewLabel_2);
		
		q4Field = new JTextField();
		q4Field.setBounds(768, 262, 185, 25);
		contentPane.add(q4Field);
		q4Field.setColumns(10);
		
		q5Field = new JTextField();
		q5Field.setBounds(768, 300, 185, 25);
		contentPane.add(q5Field);
		q5Field.setColumns(10);
		
		JButton deleteBtn = new JButton("Delete");
		deleteBtn.setBackground(new Color(0, 191, 255));
		deleteBtn.setForeground(new Color(255, 255, 255));
		deleteBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int x = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this record?", "Add records", JOptionPane.YES_NO_OPTION);
		        if(x == 0) {
		            try {
		            	Integer fid = Integer.parseInt(fidField.getText());
		            	//FeedbackInterface fi = (FeedbackInterface)Naming.lookup("rmi://localhost:1099/Feedback");
						Registry myReg = LocateRegistry.getRegistry(ipAddress, port);
						FeedbackInterface Feedback = (FeedbackInterface)myReg.lookup("Feedback");
						
			            @SuppressWarnings("unused")
						Integer result = Feedback.deleteFeedback(fid);
			            JOptionPane.showMessageDialog(null, "Record successfully deleted");
		            }
		            catch(Exception e1) {
		            	JOptionPane.showMessageDialog(null, "Error");
		            	e1.printStackTrace();
		            }
		        }
			}
		});
		deleteBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		deleteBtn.setBounds(768, 404, 185, 35);
		contentPane.add(deleteBtn);
		
		JButton updateBtn = new JButton("Update");
		updateBtn.setBackground(new Color(0, 191, 255));
		updateBtn.setForeground(new Color(255, 255, 255));
		updateBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Integer val = Integer.parseInt(fidField.getText());
		            String val2 = ftField.getText();
		            String val3 = q1Field.getText();
		            String val4 = q2Field.getText();
		            String val5 = q3Field.getText();
		            String val6 = q4Field.getText();
		            String val7 = q5Field.getText();
					//FeedbackInterface fi = (FeedbackInterface)Naming.lookup("rmi://localhost:1099/Feedback");
					Registry myReg = LocateRegistry.getRegistry(ipAddress, port);
					FeedbackInterface Feedback = (FeedbackInterface)myReg.lookup("Feedback");
		            @SuppressWarnings("unused")
					String result = Feedback.updateFeedback(val, val2, val3, val4, val5, val6, val7);
		            JOptionPane.showMessageDialog(null, "Data updated successfully");
		        } 
		        
		        catch(Exception e1) {
		            JOptionPane.showMessageDialog(null, "Error");
		            e1.printStackTrace();
		        }
			}
		});
		updateBtn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		updateBtn.setBounds(768, 356, 185, 35);
		contentPane.add(updateBtn);
		
		ViewTable();
	}
	
	private void ViewTable() {
		try {
			//FeedbackInterface fi = (FeedbackInterface)Naming.lookup("rmi://localhost:1099/Feedback");
			Registry myReg = LocateRegistry.getRegistry(ipAddress, port);
			FeedbackInterface Feedback = (FeedbackInterface)myReg.lookup("Feedback");
			ArrayList<ServerSide.FeedbackBean> result = Feedback.viewFeedback("feedbackID", "type", "question1", "question2", "question3", "question4", "question5");
			DefaultTableModel dtm = (DefaultTableModel)table.getModel();
			
			for(ServerSide.FeedbackBean feedback: result) {
				Object obj[] = {feedback.feedbackID, feedback.type, feedback.question1, feedback.question2, feedback.question3, feedback.question4, feedback.question5};
				dtm.addRow(obj);
			}
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, e);    
        }
	}
}
