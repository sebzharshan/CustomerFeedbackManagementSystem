package ClientSide;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.net.MalformedURLException;
//import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import ServerSide.FeedbackInterface;

@SuppressWarnings({ "serial" })
public class AdminLogin extends JFrame implements ActionListener {

	JTextArea username, password;
	JTextField userName, pass;
	JButton login, back;
	static int port = 1091;
	String ipAddress = "192.168.1.100";
	
	public AdminLogin() {
		setLayout(new FlowLayout());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(400, 400);
		setVisible(true);
		setTitle("Login");
		
		username = new JTextArea("Username:");
		password = new JTextArea("Password:");
		
		userName = new JTextField();
		userName.setToolTipText("Enter your name");
		pass = new JTextField();
		pass.setToolTipText("Enter your password");
		
		login = new JButton("Log In");
		login.setBackground(new Color(0, 191, 255));
		login.setForeground(new Color(255, 255, 255));
		
		back = new JButton();
		back.setBackground(new Color(0, 191, 255));
		back.setForeground(new Color(255, 255, 255));
		Image backImage = new ImageIcon(this.getClass().getResource("/back2.png")).getImage();
		back.setIcon(new ImageIcon(backImage));	
		
		//User authentication database stuff 
		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String a = userName.getText().toString();
					String b = pass.getText().toString();
					
					if(a == null || a.isEmpty() || b == null || b.isEmpty()) {
						//User is not valid
						JOptionPane.showMessageDialog(null, "Empty! Please enter your credentials!");
					}
					else {
						//user is valid
						Registry myReg = LocateRegistry.getRegistry(ipAddress, port); //1
						FeedbackInterface Feedback = (FeedbackInterface)myReg.lookup("Feedback");//2
						//FeedbackInterface Feedback = (FeedbackInterface)Naming.lookup("rmi://localhost:1078/Feedback");
						String response = Feedback.adminLogin(a, b);						
						
							if(response == null || response.isEmpty()) {
								JOptionPane.showMessageDialog(null, "Error!");
							}
							else {
								JOptionPane.showMessageDialog(null, "Welcome, "+ response+"!" + " You have logged in successfully.");	
								//System.out.println(response);
								new AdminDashboard();
								dispose();
							}
					}
				} 
				catch (RemoteException | NotBoundException e1) {
				e1.printStackTrace();

				}	
			}
	 	});
		
		Box box = Box.createVerticalBox();
		box.add(back);
		box.add(Box.createVerticalStrut(30));
		box.add(username);
		box.add(Box.createVerticalStrut(5));
		box.add(userName);
		box.add(Box.createVerticalStrut(5));
		box.add(password);
		box.add(Box.createVerticalStrut(5));
		box.add(pass);
		box.add(Box.createVerticalStrut(20));
		box.add(login);
		
		add(box);
		login.addActionListener(this);
		back.addActionListener(this);
		
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(login)) {
			//new AdminDashboard();
			//this.dispose();
		} else if(e.getSource().equals(back)){
			new StartUI();
			this.dispose();
		}
		else {
			
		}
	}
}
