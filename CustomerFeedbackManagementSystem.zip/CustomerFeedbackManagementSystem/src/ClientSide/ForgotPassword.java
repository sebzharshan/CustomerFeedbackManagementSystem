package ClientSide;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.net.MalformedURLException;
//import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import ServerSide.FeedbackInterface;

@SuppressWarnings("serial")
public class ForgotPassword extends JFrame implements ActionListener {
	
	JTextField securityQuestion, securityAnswer, username;
	JTextArea sQ, sA, userName;
	JButton resetPassword, back;
	static int port = 1091;
	String ipAddress = "192.168.1.100";

	public ForgotPassword() {
		setLayout(new FlowLayout());
		setDefaultCloseOperation(EXIT_ON_CLOSE); 
		setSize(400, 400);					  	 
		setVisible(true); 						
		setTitle("Reset Password");		
		
		userName = new JTextArea("Username:");
		sQ = new JTextArea("Security Question:");
		sA = new JTextArea("Security Answer:");		
		
		username = new JTextField();
		username.setToolTipText("Enter your username");
		securityQuestion = new JTextField();
		securityQuestion.setToolTipText("Enter your security question");
		securityAnswer = new JTextField();
		securityAnswer.setToolTipText("Enter your security answer");
		
		back = new JButton();
		back.setBackground(new Color(0, 191, 255));
		back.setForeground(new Color(255, 255, 255));
		Image backImage = new ImageIcon(this.getClass().getResource("/back2.png")).getImage();
		back.setIcon(new ImageIcon(backImage));	
		
		resetPassword = new JButton("Reset Password");
		resetPassword.setBackground(new Color(0, 191, 255));
		resetPassword.setForeground(new Color(255, 255, 255));
		
		resetPassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String a = username.getText().toString();
					String b = securityQuestion.getText().toString().toLowerCase().trim();
					String c = securityAnswer.getText().toString().toLowerCase().trim();
					
					Registry myReg = LocateRegistry.getRegistry(ipAddress, port); //1
					FeedbackInterface Feedback = (FeedbackInterface)myReg.lookup("Feedback");//2
					//FeedbackInterface Feedback = (FeedbackInterface)Naming.lookup("rmi://localhost:1078/Feedback");
					String response = Feedback.passwordReset(a, b, c);				
					
					if(response == null) {
						//User is not valid
						JOptionPane.showMessageDialog(null, "Error!");	
					}
					else {
						//user is valid
						JOptionPane.showMessageDialog(null, "Success!");	
						new ResetPassword(a);
						dispose();
					}
					
				} 
				catch (RemoteException | NotBoundException e1) {
				//JOptionPane.showMessageDialog(null, "Authentication unsuccessful! Please check your credentials.");	
				e1.printStackTrace();

				}	
			}
	 	});
		
		Box box = Box.createVerticalBox();
		box.add(back);
		box.add(Box.createVerticalStrut(30));		
		box.add(userName);
		box.add(username);
		box.add(sQ);
		box.add(securityQuestion);
		box.add(sA);
		box.add(securityAnswer);
		box.add(Box.createVerticalStrut(20));
		box.add(resetPassword);

		add(box);
		
		back.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(back)) {
			new SignIn();
			dispose();
		}
		else {
			
		}
		
	}	
}
