package ClientSide;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.net.MalformedURLException;
//import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import ServerSide.FeedbackInterface;

@SuppressWarnings("serial")
public class ResetPassword extends JFrame {
	
	JTextField userName, newPass;
	JTextArea username, newPassword;
	JButton updatePassword;
	String username2;
	static int port = 1091;
	String ipAddress = "192.168.1.100";
	
	public ResetPassword(String a) {
		setLayout(new FlowLayout());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(400, 400);
		setVisible(true);
		setTitle("Reset Password");
		
		//retrieving the username from the previous UI: ForgotPassword
		this.username2 = a;
		
		username = new JTextArea("Username:");
		newPassword = new JTextArea("New Password:");	
		
		userName = new JTextField();
		userName.setToolTipText("Enter your username");
		userName.setText(username2);//setting the username
		newPass = new JTextField();
		newPass.setToolTipText("Enter a new password");
		
		updatePassword = new JButton("Update Password");
		updatePassword.setBackground(new Color(0, 191, 255));
		updatePassword.setForeground(new Color(255, 255, 255));
		
		updatePassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String a = userName.getText().toString();
					String b = newPass.getText().toString();
					
					Registry myReg = LocateRegistry.getRegistry(ipAddress, port); //1
					FeedbackInterface Feedback = (FeedbackInterface)myReg.lookup("Feedback");//2
					//FeedbackInterface Feedback = (FeedbackInterface)Naming.lookup("rmi://localhost:1078/Feedback");
					String response = Feedback.updatePassword(a, b);				
					
					if(response == null) {
						//User is not valid
						JOptionPane.showMessageDialog(null, "Error!");	
					}
					else {
						//user is valid
						JOptionPane.showMessageDialog(null, "Password successfully updated!");	
						new SignIn();
						dispose();
					}
					
				} 
				catch (RemoteException | NotBoundException e1) {
				//JOptionPane.showMessageDialog(null, "Authentication unsuccessful! Please check your credentials.");	
				e1.printStackTrace();

				}	
			}
	 	}); 
		
		Box box = Box.createVerticalBox();
		box.add(Box.createVerticalStrut(30));
		box.add(username);
		box.add(userName);
		box.add(newPassword);
		box.add(newPass);
		box.add(Box.createVerticalStrut(20));
		box.add(updatePassword);

		add(box);
		
	}

}
