package ClientSide;

import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.web.WebView;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * @author Muhammad Aslam - 1939084
 * Implemented by referring to this code, link: https://javabeat.net/embedding-html-into-java-swing-applications/
 * Accessed on 7th of April 2020
 */
@SuppressWarnings("serial")
public class ViewAnalytics extends JFrame{
	
	 JFXPanel javafxPanel;
	 WebView webComponent;
	 JPanel mainPanel;

	 JComboBox<Object> feedbackType;
	 JButton searchButton, back;

	 public ViewAnalytics(){

	 javafxPanel = new JFXPanel();

	    initSwingComponents();

	    loadJavaFXScene();
	  }

	  /**
	  * Instantiate the Swing components to be used
	  */
	  private void initSwingComponents(){
	    mainPanel = new JPanel();
	    mainPanel.setLayout(new BorderLayout());
	    mainPanel.add(javafxPanel, BorderLayout.CENTER);
	    setVisible(true); //crucial

	    JPanel feedbackTypePanel = new JPanel(new FlowLayout());
	    feedbackType = new JComboBox<Object>();
	    feedbackType.setModel(new DefaultComboBoxModel<Object>(new String[] {"Electronic Products", "Food", "Apparel", "Automotive"}));
	    feedbackTypePanel.add(feedbackType);
	    searchButton = new JButton("Search");
	    
	    back = new JButton("Back");
		back.setBackground(new Color(0, 191, 255));
		back.setForeground(new Color(255, 255, 255));
		back.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				AdminDashboard al = new AdminDashboard();
				al.setVisible(true);
				dispose();
			}
		});
			

	    /**
	     * Handling the loading of new URL, when the user
	     * enters the URL and clicks on Go button.
	     */
		searchButton.setBackground(new Color(0, 191, 255));
		searchButton.setForeground(new Color(255, 255, 255));
	    searchButton.addActionListener(new ActionListener() {
	      @Override
	      public void actionPerformed(ActionEvent e) {
	        Platform.runLater(new Runnable() {
	          @Override
	          public void run() {
	            String url = feedbackType.getName();
	            if ( url != null && url.length() > 0){
	                webComponent.getEngine().load(url);
	            }
	          }
	        });

	      }
	    });

	    feedbackTypePanel.add(searchButton);
	    //back.setBounds(12, 12, 80, 25);
		feedbackTypePanel.add(back);
	    mainPanel.add(feedbackTypePanel, BorderLayout.NORTH);

	    this.add(mainPanel);
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setSize(700,600);
	  }

	  /**
	  * Instantiate the JavaFX Components in
	  * the JavaFX Application Thread.
	  */
	  private void loadJavaFXScene(){
	    Platform.runLater(new Runnable() {
	      @Override
	      public void run() {

	        BorderPane borderPane = new BorderPane();
	        webComponent = new WebView();

	        webComponent.getEngine().load("https://chartscomponent.azurewebsites.net/");

	        borderPane.setCenter(webComponent);
	        Scene scene = new Scene(borderPane,450,450);
	        javafxPanel.setScene(scene);

	      }
	    });
	  }
}