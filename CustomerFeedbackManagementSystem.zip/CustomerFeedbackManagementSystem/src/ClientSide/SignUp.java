package ClientSide;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
//import java.net.MalformedURLException;
//import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import ServerSide.FeedbackInterface;

//import java.sql.*;

@SuppressWarnings("serial")
public class SignUp extends JFrame implements ActionListener {

	JTextField name, username, email, password, confirmPassword, securityQuestion, securityAnswer; 
	JTextArea nameText, userText, eText, pText, cPText, sQ, sA, sMessage, sMessage2;
	JButton signUp, back, save;
	static int port = 1091;
	String ipAddress = "192.168.1.100";

	public SignUp() {
		setLayout(new FlowLayout());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(700, 600);
		setVisible(true);
		setTitle("Sign Up");
		
		name = new JTextField();
		name.setToolTipText("Enter your name");
		username = new JTextField();
		username.setToolTipText("Enter a username");
		email = new JTextField();
		email.setToolTipText("Enter your email");
		password = new JTextField();
		password.setToolTipText("Enter a password");
		//confirmPassword = new JTextField();
		//confirmPassword.setToolTipText("Re-enter your password for confirmation");
		securityQuestion = new JTextField();
		securityQuestion.setToolTipText("Enter a security question");
		securityAnswer = new JTextField();
		securityAnswer.setToolTipText("Enter a security answer");		
		
		nameText = new JTextArea("Name:");
		userText = new JTextArea("Username:");
		eText = new JTextArea("Email: ");
		pText = new JTextArea("Password: ");
		//cPText = new JTextArea("Confirm Password: ");
		sQ = new JTextArea("Security Question:");
		sA = new JTextArea("Security Answer:");
		sMessage = new JTextArea("***Please note: For the case of resetting your password, it is crucial that you save your Security Question and Answer.");
		sMessage2 = new JTextArea("***To save, press 'Save Security Credentials' button after typing your Security Question and Answer. ");
		
		signUp = new JButton("Sign Up");
		signUp.setBackground(new Color(0, 191, 255));
		signUp.setForeground(new Color(255, 255, 255));
		
		back = new JButton();
		back.setBackground(new Color(0, 191, 255));
		back.setForeground(new Color(255, 255, 255));
		Image backImage = new ImageIcon(this.getClass().getResource("/back2.png")).getImage();
		back.setIcon(new ImageIcon(backImage));	
		
		save = new JButton("Save Security Credentials");
		save.setBackground(new Color(0, 191, 255));
		save.setForeground(new Color(255, 255, 255));
		
		//User Registration database stuff
		signUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				 
				try {
					String a = name.getText().toString();
					String b = username.getText().toString();
					String d = email.getText().toString();
					String c = password.getText().toString();
					//String e3 = confirmPassword.getText().toString();
					String f = securityQuestion.getText().toString().toLowerCase().trim();
					String g = securityAnswer.getText().toString().toLowerCase().trim();
					
					Registry myReg = LocateRegistry.getRegistry(ipAddress, port); //1
					FeedbackInterface Feedback = (FeedbackInterface)myReg.lookup("Feedback");	//Naming to myReg and rmi://localhost:1078/ to Fedback(lookup string)				
					//FeedbackInterface Feedback = (FeedbackInterface)Naming.lookup("rmi://localhost:1078/Feedback");
					@SuppressWarnings("unused")
					String result = Feedback.userRegistration(a, b, c, d, f, g); 
					
					JOptionPane.showMessageDialog(null, "Registration successful.");	
					new SignIn();
					dispose();						
				} catch (RemoteException | NotBoundException e1) { //MalformedURLException taken off - Feedback underline error
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, "Error! Registration usuccessful.");	
					e1.printStackTrace();
				}					
			}	
	 	});
		
		save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				 
			
				JFileChooser fc = new JFileChooser(new File("C:\\"));
				fc.setDialogTitle("Save your security question and answer");
				fc.setFileFilter(new QADetails(".txt", "Text File"));
				int response = fc.showSaveDialog(null);
				
					if(response == JFileChooser.APPROVE_OPTION) {
						String text = securityQuestion.getText();
						String text2 = securityAnswer.getText();
						File file = fc.getSelectedFile();
							
							try {
								FileWriter filewriter = new FileWriter(file.getPath());
								filewriter.write("Security Question: ");
								filewriter.write(text);
								filewriter.write("\n") ;
								filewriter.write("Security Answer: ");								
								filewriter.write(text2);
								filewriter.flush();
								filewriter.close();
								JOptionPane.showMessageDialog(null, "Credentails Saved!");	
							}
							catch(Exception e2) {
								System.out.print(e2);
							}
					}
					else {
						
					}				
			}	
	 	});		
		
		Box box = Box.createVerticalBox();
		box.add(back);
		box.add(Box.createVerticalStrut(30));
		box.add(nameText);
		box.add(name);
		box.add(Box.createVerticalStrut(5));
		box.add(userText);
		box.add(username);
		box.add(Box.createVerticalStrut(5));
		box.add(eText);
		box.add(email);
		box.add(Box.createVerticalStrut(5));
		box.add(pText);
		box.add(password);
		box.add(Box.createVerticalStrut(5));
		//box.add(cPText);
		//box.add(confirmPassword);
		box.add(Box.createVerticalStrut(60));
		box.add(sMessage);
		box.add(sMessage2);
		box.add(sQ);
		box.add(securityQuestion);
		box.add(sA);
		box.add(securityAnswer);		
		box.add(signUp);
		box.add(Box.createVerticalStrut(10));
		box.add(save);	
		
		add(box);
		
		back.addActionListener(this);
		
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(back)) {
			new SignIn();
			this.dispose();
		}
		else{
			
		}
	}
}

